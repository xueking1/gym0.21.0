import os
import numpy as np

from gym import utils, error
from gym.envs.robotics import rotations, hand_env  # 导入机器人手环境相关模块
from gym.envs.robotics.utils import robot_get_obs  # 导入获取机器人观测的工具函数

try:
    import mujoco_py  # 导入MuJoCo物理引擎的Python接口
except ImportError as e:
    # 如果导入失败，抛出依赖未安装的异常
    raise error.DependencyNotInstalled(
        "{}. (HINT: you need to install mujoco_py, and also perform the setup instructions here: https://github.com/openai/mujoco-py/.)".format(
            e
        )
    )


def quat_from_angle_and_axis(angle, axis):
    """从角度和轴创建四元数"""
    assert axis.shape == (3,)
    axis /= np.linalg.norm(axis)  # 归一化轴向量
    quat = np.concatenate([[np.cos(angle / 2.0)], np.sin(angle / 2.0) * axis])  # 四元数公式
    quat /= np.linalg.norm(quat)  # 归一化四元数
    return quat


# 确保在Windows上正确获取路径分隔符
MANIPULATE_BLOCK_XML = os.path.join("hand", "manipulate_block.xml")  # 方块操作环境的XML文件
MANIPULATE_EGG_XML = os.path.join("hand", "manipulate_egg.xml")  # 蛋操作环境的XML文件
MANIPULATE_PEN_XML = os.path.join("hand", "manipulate_pen.xml")  # 笔操作环境的XML文件


class ManipulateEnv(hand_env.HandEnv):
    """机器人手操作环境基类，继承自HandEnv"""

    def __init__(
            self,
            model_path,  # 环境XML文件路径
            target_position,  # 目标位置类型：ignore/fixed/random
            target_rotation,  # 目标旋转类型：ignore/fixed/xyz/z/parallel
            target_position_range,  # 目标位置随机范围
            reward_type,  # 奖励类型：sparse/dense
            initial_qpos=None,  # 初始关节位置
            randomize_initial_position=True,  # 是否随机化初始位置
            randomize_initial_rotation=True,  # 是否随机化初始旋转
            distance_threshold=0.01,  # 位置成功阈值(米)
            rotation_threshold=0.1,  # 旋转成功阈值(弧度)
            n_substeps=20,  # 每步模拟的子步数
            relative_control=False,  # 是否使用相对控制
            ignore_z_target_rotation=False,  # 是否忽略Z轴旋转
    ):
        # 初始化参数
        self.target_position = target_position
        self.target_rotation = target_rotation
        self.target_position_range = target_position_range
        # 预计算平行旋转的四元数
        self.parallel_quats = [
            rotations.euler2quat(r) for r in rotations.get_parallel_rotations()
        ]
        self.randomize_initial_rotation = randomize_initial_rotation
        self.randomize_initial_position = randomize_initial_position
        self.distance_threshold = distance_threshold
        self.rotation_threshold = rotation_threshold
        self.reward_type = reward_type
        self.ignore_z_target_rotation = ignore_z_target_rotation

        # 验证参数有效性
        assert self.target_position in ["ignore", "fixed", "random"]
        assert self.target_rotation in ["ignore", "fixed", "xyz", "z", "parallel"]
        initial_qpos = initial_qpos or {}

        # 调用父类初始化
        hand_env.HandEnv.__init__(
            self,
            model_path,
            n_substeps=n_substeps,
            initial_qpos=initial_qpos,
            relative_control=relative_control,
        )

    def _get_achieved_goal(self):
        """获取当前实现的目标（物体位置和旋转）"""
        # 获取物体关节的位置和旋转（7维：[x, y, z, qx, qy, qz, qw]）
        object_qpos = self.sim.data.get_joint_qpos("object:joint")
        assert object_qpos.shape == (7,)
        return object_qpos

    def _goal_distance(self, goal_a, goal_b):
        """计算两个目标之间的距离（位置和旋转）"""
        assert goal_a.shape == goal_b.shape
        assert goal_a.shape[-1] == 7  # 确保是7维目标

        d_pos = np.zeros_like(goal_a[..., 0])
        d_rot = np.zeros_like(goal_b[..., 0])

        # 计算位置距离
        if self.target_position != "ignore":
            delta_pos = goal_a[..., :3] - goal_b[..., :3]  # 位置差值
            d_pos = np.linalg.norm(delta_pos, axis=-1)  # 欧氏距离

        # 计算旋转距离
        if self.target_rotation != "ignore":
            quat_a, quat_b = goal_a[..., 3:], goal_b[..., 3:]  # 提取四元数

            # 如果忽略Z轴旋转
            if self.ignore_z_target_rotation:
                # 转换为欧拉角，设置Z分量相同，再转回四元数
                euler_a = rotations.quat2euler(quat_a)
                euler_b = rotations.quat2euler(quat_b)
                euler_a[2] = euler_b[2]  # 设置相同的Z旋转
                quat_a = rotations.euler2quat(euler_a)

            # 计算四元数差异的角度
            quat_diff = rotations.quat_mul(quat_a, rotations.quat_conjugate(quat_b))
            angle_diff = 2 * np.arccos(np.clip(quat_diff[..., 0], -1.0, 1.0))
            d_rot = angle_diff

        assert d_pos.shape == d_rot.shape
        return d_pos, d_rot

    # GoalEnv方法
    # ----------------------------

    def compute_reward(self, achieved_goal, goal, info):
        """计算奖励函数"""
        if self.reward_type == "sparse":
            # 稀疏奖励：成功返回0，失败返回-1
            success = self._is_success(achieved_goal, goal).astype(np.float32)
            return success - 1.0
        else:
            # 密集奖励：加权位置和旋转距离
            d_pos, d_rot = self._goal_distance(achieved_goal, goal)
            return -(10.0 * d_pos + d_rot)  # 位置距离权重更大

    # RobotEnv方法
    # ----------------------------

    def _is_success(self, achieved_goal, desired_goal):
        """判断是否成功达成目标"""
        d_pos, d_rot = self._goal_distance(achieved_goal, desired_goal)
        achieved_pos = (d_pos < self.distance_threshold).astype(np.float32)  # 位置是否达标
        achieved_rot = (d_rot < self.rotation_threshold).astype(np.float32)  # 旋转是否达标
        achieved_both = achieved_pos * achieved_rot  # 两者都达标才算成功
        return achieved_both

    def _env_setup(self, initial_qpos):
        """环境设置：初始化关节位置"""
        for name, value in initial_qpos.items():
            self.sim.data.set_joint_qpos(name, value)  # 设置关节位置
        self.sim.forward()  # 前向模拟一步以更新状态

    def _reset_sim(self):
        """重置模拟器"""
        self.sim.set_state(self.initial_state)  # 重置到初始状态
        self.sim.forward()  # 更新模拟器状态

        # 获取物体的初始位置和旋转
        initial_qpos = self.sim.data.get_joint_qpos("object:joint").copy()
        initial_pos, initial_quat = initial_qpos[:3], initial_qpos[3:]
        assert initial_qpos.shape == (7,)
        assert initial_pos.shape == (3,)
        assert initial_quat.shape == (4,)
        initial_qpos = None

        # 随机化初始旋转
        if self.randomize_initial_rotation:
            if self.target_rotation == "z":
                # 仅绕Z轴随机旋转
                angle = self.np_random.uniform(-np.pi, np.pi)
                axis = np.array([0.0, 0.0, 1.0])
                offset_quat = quat_from_angle_and_axis(angle, axis)
                initial_quat = rotations.quat_mul(initial_quat, offset_quat)
            elif self.target_rotation == "parallel":
                # 平行旋转（Z轴+对齐旋转）
                angle = self.np_random.uniform(-np.pi, np.pi)
                axis = np.array([0.0, 0.0, 1.0])
                z_quat = quat_from_angle_and_axis(angle, axis)
                parallel_quat = self.parallel_quats[
                    self.np_random.randint(len(self.parallel_quats))
                ]
                offset_quat = rotations.quat_mul(z_quat, parallel_quat)
                initial_quat = rotations.quat_mul(initial_quat, offset_quat)
            elif self.target_rotation in ["xyz", "ignore"]:
                # 完全随机旋转
                angle = self.np_random.uniform(-np.pi, np.pi)
                axis = self.np_random.uniform(-1.0, 1.0, size=3)
                offset_quat = quat_from_angle_and_axis(angle, axis)
                initial_quat = rotations.quat_mul(initial_quat, offset_quat)
            elif self.target_rotation == "fixed":
                # 固定旋转，不做处理
                pass
            else:
                raise error.Error(
                    'Unknown target_rotation option "{}".'.format(self.target_rotation)
                )

        # 随机化初始位置
        if self.randomize_initial_position:
            if self.target_position != "fixed":
                initial_pos += self.np_random.normal(size=3, scale=0.005)

        # 归一化四元数并设置物体位置
        initial_quat /= np.linalg.norm(initial_quat)
        initial_qpos = np.concatenate([initial_pos, initial_quat])
        self.sim.data.set_joint_qpos("object:joint", initial_qpos)

        def is_on_palm():
            """检查物体是否在手掌上"""
            self.sim.forward()
            cube_middle_idx = self.sim.model.site_name2id("object:center")
            cube_middle_pos = self.sim.data.site_xpos[cube_middle_idx]
            is_on_palm = cube_middle_pos[2] > 0.04  # Z高度大于0.04米
            return is_on_palm

        # 运行10步模拟让物体稳定
        for _ in range(10):
            self._set_action(np.zeros(20))  # 零动作
            try:
                self.sim.step()
            except mujoco_py.MujocoException:
                return False
        return is_on_palm()  # 返回物体是否在手掌上

    def _sample_goal(self):
        """采样目标位置和旋转"""
        # 采样目标位置
        target_pos = None
        if self.target_position == "random":
            # 在指定范围内随机偏移
            assert self.target_position_range.shape == (3, 2)
            offset = self.np_random.uniform(
                self.target_position_range[:, 0], self.target_position_range[:, 1]
            )
            assert offset.shape == (3,)
            target_pos = self.sim.data.get_joint_qpos("object:joint")[:3] + offset
        elif self.target_position in ["ignore", "fixed"]:
            # 使用当前位置
            target_pos = self.sim.data.get_joint_qpos("object:joint")[:3]
        else:
            raise error.Error(
                'Unknown target_position option "{}".'.format(self.target_position)
            )
        assert target_pos is not None
        assert target_pos.shape == (3,)

        # 采样目标旋转
        target_quat = None
        if self.target_rotation == "z":
            # 仅绕Z轴随机旋转
            angle = self.np_random.uniform(-np.pi, np.pi)
            axis = np.array([0.0, 0.0, 1.0])
            target_quat = quat_from_angle_and_axis(angle, axis)
        elif self.target_rotation == "parallel":
            # 平行旋转（Z轴+对齐旋转）
            angle = self.np_random.uniform(-np.pi, np.pi)
            axis = np.array([0.0, 0.0, 1.0])
            target_quat = quat_from_angle_and_axis(angle, axis)
            parallel_quat = self.parallel_quats[
                self.np_random.randint(len(self.parallel_quats))
            ]
            target_quat = rotations.quat_mul(target_quat, parallel_quat)
        elif self.target_rotation == "xyz":
            # 完全随机旋转
            angle = self.np_random.uniform(-np.pi, np.pi)
            axis = self.np_random.uniform(-1.0, 1.0, size=3)
            target_quat = quat_from_angle_and_axis(angle, axis)
        elif self.target_rotation in ["ignore", "fixed"]:
            # 使用当前旋转
            target_quat = self.sim.data.get_joint_qpos("object:joint")
        else:
            raise error.Error(
                'Unknown target_rotation option "{}".'.format(self.target_rotation)
            )
        assert target_quat is not None
        assert target_quat.shape == (4,)

        # 归一化四元数并组合成目标
        target_quat /= np.linalg.norm(target_quat)
        goal = np.concatenate([target_pos, target_quat])
        return goal

    def _render_callback(self):
        """渲染回调：设置目标物体的可视化位置"""
        goal = self.goal.copy()
        assert goal.shape == (7,)
        if self.target_position == "ignore":
            # 如果不关心位置，将目标物体移到一侧
            goal[0] += 0.15
        # 设置目标关节的位置和速度
        self.sim.data.set_joint_qpos("target:joint", goal)
        self.sim.data.set_joint_qvel("target:joint", np.zeros(6))

        # 如果存在隐藏物体，显示它
        if "object_hidden" in self.sim.model.geom_names:
            hidden_id = self.sim.model.geom_name2id("object_hidden")
            self.sim.model.geom_rgba[hidden_id, 3] = 1.0  # 设置透明度为不透明
        self.sim.forward()  # 更新模拟器

    def _get_obs(self):
        """获取环境观测"""
        # 获取机器人关节位置和速度
        robot_qpos, robot_qvel = robot_get_obs(self.sim)
        # 获取物体关节速度
        object_qvel = self.sim.data.get_joint_qvel("object:joint")
        # 获取当前实现的目标（物体位置和旋转）
        achieved_goal = self._get_achieved_goal().ravel()

        # 组合观测：机器人状态 + 物体速度 + 当前目标
        observation = np.concatenate(
            [robot_qpos, robot_qvel, object_qvel, achieved_goal]
        )

        return {
            "observation": observation.copy(),  # 环境状态观测
            "achieved_goal": achieved_goal.copy(),  # 当前达成的目标
            "desired_goal": self.goal.ravel().copy(),  # 期望的目标
        }


# 具体环境实现：方块操作环境
class HandBlockEnv(ManipulateEnv, utils.EzPickle):
    def __init__(
            self, target_position="random", target_rotation="xyz", reward_type="sparse"
    ):
        utils.EzPickle.__init__(self, target_position, target_rotation, reward_type)
        ManipulateEnv.__init__(
            self,
            model_path=MANIPULATE_BLOCK_XML,  # 使用方块的XML模型
            target_position=target_position,
            target_rotation=target_rotation,
            target_position_range=np.array([(-0.04, 0.04), (-0.06, 0.02), (0.0, 0.06)]),  # 位置随机范围
            reward_type=reward_type,
        )


# 具体环境实现：蛋操作环境
class HandEggEnv(ManipulateEnv, utils.EzPickle):
    def __init__(
            self, target_position="random", target_rotation="xyz", reward_type="sparse"
    ):
        utils.EzPickle.__init__(self, target_position, target_rotation, reward_type)
        ManipulateEnv.__init__(
            self,
            model_path=MANIPULATE_EGG_XML,  # 使用蛋的XML模型
            target_position=target_position,
            target_rotation=target_rotation,
            target_position_range=np.array([(-0.04, 0.04), (-0.06, 0.02), (0.0, 0.06)]),  # 位置随机范围
            reward_type=reward_type,
        )


# 具体环境实现：笔操作环境
class HandPenEnv(ManipulateEnv, utils.EzPickle):
    def __init__(
            self, target_position="random", target_rotation="xyz", reward_type="sparse"
    ):
        utils.EzPickle.__init__(self, target_position, target_rotation, reward_type)
        ManipulateEnv.__init__(
            self,
            model_path=MANIPULATE_PEN_XML,  # 使用笔的XML模型
            target_position=target_position,
            target_rotation=target_rotation,
            target_position_range=np.array([(-0.04, 0.04), (-0.06, 0.02), (0.0, 0.06)]),  # 位置随机范围
            randomize_initial_rotation=False,  # 不随机化初始旋转
            reward_type=reward_type,
            ignore_z_target_rotation=True,  # 忽略Z轴旋转
            distance_threshold=0.05,  # 更大的位置阈值
        )